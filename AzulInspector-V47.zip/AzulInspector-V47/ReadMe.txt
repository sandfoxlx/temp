Azul Inspector Read Me.

Azul Inspector collects details about the Host System and the target Java Application that will run on Zing. This helps to make sure that the environment has the minimum requirements. 

Load the AzulInspector zip file on the Host System, unzip it and run the runMe.sh. Make sure the runMe.sh file has execute permissions. If you can run it as admin (or sudo) then it will be able to verify the environment. If you run it with a user who does not have admin permissions, it will only be able to verify some of the environment.
 
If you can't load the AzulInspector zip file to no the target host, you can run it remotely, for example, from your desktop. But you need to provide some additional command line options:
 
java -DSystemQualification=true -DRMTProbe=true -DRMTHost=xxxx -DRMTUser=xxxx -DRMTPass=xxx -DRJCMD=true -DRJCMDPid=xxxx -jar AzulInspector.jar | tee `hostname`-AzulSystemQual.`date +%F-%H%M`.log
 
Change the xxxx above to values for your environment.
 
When AzulInspector is finished running, a file ending with AzulSystemQual.`date +%F-%H%M`.log will be in the current directory, please review that and email it us so we can verify the environment and application.

Agent Support:
AzulInspector can execute as an agent. The agent has two modes, it always prints a small subset of the SystemQualification output when the JVM starts
If the string MonitorMode is passed as a parameter to the agent, a separate JVM process is started to monitor all JVM's on the system
-javaagent:/AzulInspector.jar=MonitorMode
The output from the agent when SystemQualification is done, is the JVM's standard out
The output from the agent when MonitorMode is used, is the AzulInspector-MonitorMode file in the AzulInspector directory

Filter Output:
By default AzulInspector collects a number of metrics about the system and JVM process, if you wish to limit the data collected, a filter can be set, for example:

java -DFilter="[11],[4],[2],[1],[12]" -classpath AzulInspector.jar azulinspector.EnvCheck | tee `hostname`-AzulSystemQual.`date +%F-%H%M`.log

This would only return the specified eye catchers (cpu, sysctl, hostname, uname and meminfo)

If you did not wish to report JMX metrics, add -DPrintMBeans=false -DGenerateMBeans=false -DJCMD=true options to the AzulInspector command line.
You only need to run one AzulInspector per system.

Reviewing the AzulInspector System Qualification Log.
Once a AzulInspector System Qualification log is available (output of runMe.sh) the script runCheckResults.sh can be used to review the file.

Just execute the script ./runCheckResults.sh the last log file will be used automatically. If you would like to use a different log, pass the filename as a parameter for example ./runCheckResults.sh my-hostfile-AzulSystemQual-date.log
